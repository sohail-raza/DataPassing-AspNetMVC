﻿using HochandaTaskMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace HochandaTaskMVC.Controllers
{
    public class MultiplesController : Controller
    {
        [Route("QuestionOne/Index")]
        public IActionResult Index()
        {
            MultiplesModel model = new MultiplesModel();
            model.MultOf = 3;
            for(int i=0;i<101; i++)
            {
                model.NumberList.Add(i);
            }
            return View(model);
        }

        
    }

}
