﻿namespace HochandaTaskMVC.Models
{
    public class MultiplesModel
    {
        public int Id { get; set; }
        public List<int> NumberList { get; set; } = new List<int>();
        public int MultOf { get; set; }
    }
}
